import { QuestionModel } from "../models/questions-schema.js";
export const viewAllQuestion = async () => {
  try {
    const docs = await QuestionModel.find({}).exec();
    return docs;
  } catch (err) {
    throw err;
  }
};
